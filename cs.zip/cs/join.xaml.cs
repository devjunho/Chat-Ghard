﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Sockets;
using System.Xml.Linq;
using cs.Models;

namespace cs
{
    public partial class join : Page
    {
        private TcpClient client;
        public join(TcpClient clientFromPreviousPage)
        {
            InitializeComponent();
            client = clientFromPreviousPage; // 전달된 TcpClient 객체를 저장합니다.
        }
        static void JSON_INFO(User user_info, JObject JSON_STR)
        {
            JSON_STR["user_id"] = user_info.User_id;
            JSON_STR["user_pw"] = user_info.User_pw;
            JSON_STR["user_name"] = user_info.User_name;
        }

        private void Connect(User user_info)
        {
            Change change = new Change(); // Change 클래스의 인스턴스를 생성합니다
            try
            {
                using (NetworkStream stream = client.GetStream())
                {
                    JObject JSON_STR = new JObject();
                    JSON_INFO(user_info, JSON_STR);
                    change.SERIALIZATION_to_send(JSON_STR, stream);
                    change.DESERIALIZATION_to_receive(JSON_STR, stream);
                }
            }
            catch (SocketException e)
            {
                MessageBox.Show("SocketException: " + e, "ERROR");
            }
            catch (Exception e)
            {
                MessageBox.Show("Exception: " + e, "ERROR");
            }
        }

        private void btn_complete_Click(object sender, RoutedEventArgs e)
        {
            User User_Info = new User();
            JObject JSON_STR = new JObject();

            if (string.IsNullOrEmpty(Name.Text) ||
                string.IsNullOrEmpty(ID.Text) ||
                string.IsNullOrEmpty(Password.Text))
            {
                MessageBox.Show("빈칸 없이 입력해 주세요.", "ERROR");
            }
            else
            {
                User_Info.User_name = Name.Text;
                User_Info.User_id = ID.Text;
                User_Info.User_pw = Password.Text;
                MessageBox.Show("회원가입에 성공하였습니다.", "축하합니다.");

                // 전달받은 TcpClient 객체를 사용하여 서버와 통신합니다.
                Connect(User_Info);
                NavigationService.Navigate(new Uri("/login.xaml", UriKind.Relative));
            }
        }
    }
}