﻿using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace cs.Models
{
    class Change
    {
        public void SERIALIZATION_to_send(JObject JSON_STR, NetworkStream stream)
        {
            var serialization_data = JsonConvert.SerializeObject(JSON_STR); // 직렬화
            byte[] data = Encoding.UTF8.GetBytes(serialization_data); // 직렬화 후 데이터 인코딩

            byte[] length = BitConverter.GetBytes(data.Length);//길이 측정



            if (BitConverter.IsLittleEndian)//통신 방법에 맞춤 빅엔디안으로 변경
                Array.Reverse(length);

            stream.Write(length, 0, length.Length);
            stream.Write(data, 0, data.Length);
        }

        public void DESERIALIZATION_to_receive(JObject JSON_STR, NetworkStream stream)
        {
            byte[] data = new byte[256];
            int bytes = stream.Read(data, 0, data.Length);
            string responseData = Encoding.UTF8.GetString(data, 0, bytes);
            var Deserialization_data = JsonConvert.DeserializeObject(responseData);// 역직렬화

            Console.WriteLine("수신: {0}", Deserialization_data);
        }
    }
}
