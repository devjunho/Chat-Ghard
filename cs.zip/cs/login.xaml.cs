﻿using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using cs.Models;
using System.Windows.Controls.Primitives;

namespace cs
{
    /// <summary>
    /// login.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class login : Page
    {
        public login()
        {
            InitializeComponent();
            if (login.client == null || !login.client.Connected)
            {
                Connect(); // TcpClient 객체가 null이거나 연결되어 있지 않은 경우에만 연결을 초기화합니다.
            }
        }
        public static TcpClient client = new TcpClient();

        public class Server_Address
        {
            public string IP { get; set; }
            public string Port { get; set; }
        }
        static void JSON_INFO(User user_info, JObject JSON_STR)
        {
            JSON_STR["user_id"] = user_info.User_id;
            JSON_STR["user_pw"] = user_info.User_pw;
        }
        static void Connect()
        {
            try
            {
                Server_Address Connect_adress = new Server_Address();
                Connect_adress.IP = "10.10.21.119";
                Connect_adress.Port = "1234";

                client = new TcpClient(Connect_adress.IP, int.Parse(Connect_adress.Port));
            }
            catch (SocketException e)
            {
                MessageBox.Show("SocketException: " + e, "ERROR");
            }
            catch (Exception e)
            {
                MessageBox.Show("Exception: " + e, "ERROR");
            }
        }
        private void Send(User user_info)
        {
            Change change = new Change(); // Change 클래스의 인스턴스를 생성합니다
            try
            {
                using (NetworkStream stream = client.GetStream())
                {
                    JObject JSON_STR = new JObject();
                    JSON_INFO(user_info, JSON_STR);
                    change.SERIALIZATION_to_send(JSON_STR, stream);
                    change.DESERIALIZATION_to_receive(JSON_STR, stream);
                }
            }
            catch (SocketException e)
            {
                MessageBox.Show("SocketException: " + e, "ERROR");
            }
            catch (Exception e)
            {
                MessageBox.Show("Exception: " + e, "ERROR");
            }
        }
        private void btn_join_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("회원가입 화면으로 이동합니다");
            NavigationService.Navigate(new join(client)); // 두 번째 페이지로 넘어갈 때 TcpClient 객체를 전달합니다.
        }

        private void btn_login_Click(object sender, RoutedEventArgs e)
        {
            User User_Info = new User();
            JObject JSON_STR = new JObject();

            if (string.IsNullOrEmpty(IDID.Text) ||
                string.IsNullOrEmpty(PwPw.Text))
            {
                MessageBox.Show("아이디와 비밀번호를 입력해주세요.", "ERROR");
            }
            else    // 추후에 DB에서 아이디, 비번 조회 후 로그인 하도록 로직 짜기
            {
                User_Info.User_id = IDID.Text;
                User_Info.User_pw = PwPw.Text;

                // 전달받은 TcpClient 객체를 사용하여 서버와 통신합니다.
                Send(User_Info);
                MessageBox.Show("로그인 성공");
                NavigationService.Navigate(new QNA(client));
            }
        }       
    }
}