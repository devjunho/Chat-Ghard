﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Net.Sockets;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Unicode;
using System.Xml.Linq;

namespace EchoClient
{
    public class USER_INFO
    {
        public string user_name { get; set; }
        public string user_id { get; set; }
        public string user_pw { get; set; }
        
    }

    public class Server_Address
    {
        public string IP { get; set; }
        public string Port { get; set; }
    }
    class MainApp
    {
        static void membership(USER_INFO user_info)
        {
            Console.Write("이름 입력 : ");
            user_info.user_name = Console.ReadLine();

            Console.Write("아이디 입력 : ");
            user_info.user_id = Console.ReadLine();

            Console.Write("비밀 번호 입력 : ");
            user_info.user_pw = Console.ReadLine();
        }
        static void JSON_INFO(USER_INFO user_info, JObject JSON_STR)
        {
            JSON_STR["user_id"] = user_info.user_id;
            JSON_STR["user_pw"] = user_info.user_pw;
            JSON_STR["user_name"] = user_info.user_name;
        }

        static void SERIALIZATION_to_send(JObject JSON_STR, NetworkStream stream)
        {
            var serialization_data = JsonConvert.SerializeObject(JSON_STR); // 직렬화
            byte[] data = Encoding.UTF8.GetBytes(serialization_data); // 직렬화 후 데이터 인코딩

            byte[] length = BitConverter.GetBytes(data.Length);//길이 측정

            

            if (BitConverter.IsLittleEndian)//통신 방법에 맞춤 빅엔디안으로 변경
                Array.Reverse(length);
            
            stream.Write(length, 0, length.Length);
            stream.Write(data, 0, data.Length);
        }



        static void DESERIALIZATION_to_receive(JObject JSON_STR, NetworkStream stream)
        {
            byte[] data = new byte[256];
            int bytes = stream.Read(data, 0, data.Length);
            string responseData = Encoding.UTF8.GetString(data, 0, bytes);
            var Deserialization_data = JsonConvert.DeserializeObject(responseData);// 역직렬화

            Console.WriteLine("수신: {0}", Deserialization_data);
        }
        static async Task Main(string[] args)
        {
            try
            {
                Server_Address Connect_adress = new Server_Address();

                Console.WriteLine("안녕하세요!!");


                Console.Write("서버 IP 입력 : ");
                Connect_adress.IP = Console.ReadLine();

                Console.Write("서버 Port 입력 : ");
                Connect_adress.Port = Console.ReadLine();

                using (TcpClient client = new TcpClient(Connect_adress.IP, int.Parse(Connect_adress.Port)))
                {
                    using (NetworkStream stream = client.GetStream())
                    {
                        USER_INFO  user_info = new USER_INFO();
                        JObject JSON_STR = new JObject();
                       
                        while (true)
                        { 
                            membership(user_info);
                            JSON_INFO(user_info, JSON_STR);
                            SERIALIZATION_to_send(JSON_STR, stream);
                            DESERIALIZATION_to_receive(JSON_STR, stream);
                        }
                    }
                }
            }
            catch (SocketException e)
            {
                Console.WriteLine("SocketException: {0}", e);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: {0}", e);
            }

            Console.WriteLine("클라이언트를 종료합니다.");
        }
    }
}
