﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static cs.QNA;
using Newtonsoft.Json;
using cs.Models;

using System.IO;
using System.Net;
using MySqlX.XDevAPI.Common;
using System.Net.Sockets;
using Newtonsoft.Json.Linq;

namespace cs
{

    public partial class QNA : Page
    {
        private TcpClient Client;
        static string date_str = "";
       
        public QNA(TcpClient clientFromPreviousPage)
        {
            InitializeComponent();
            Client = clientFromPreviousPage; // 전달된 TcpClient 객체를 저장합니다.

            List<City> Cities = new List<City>();           // 도시 리스트뷰

            City cityA = new City();
            cityA.Number = "108";
            cityA.Name = "서울";

            City cityB = new City();
            cityB.Number = "112";
            cityB.Name = "인천";

            City cityC = new City();
            cityC.Number = "119";
            cityC.Name = "수원";

            City cityD = new City();
            cityD.Number = "133";
            cityD.Name = "대전";

            City cityE = new City();
            cityE.Number = "143";
            cityE.Name = "대구";

            City cityF = new City();
            cityF.Number = "152";
            cityF.Name = "울산";

            City cityG = new City();
            cityG.Number = "156";
            cityG.Name = "광주";

            City cityH = new City();
            cityH.Number = "159";
            cityH.Name = "부산";

            Cities.Add(cityA);
            Cities.Add(cityB);
            Cities.Add(cityC);
            Cities.Add(cityD);
            Cities.Add(cityE);
            Cities.Add(cityF);
            Cities.Add(cityG);
            Cities.Add(cityH);

            ListView_City.ItemsSource = Cities;

            List<City> Weathers = new List<City>();           // 날씨 목록 리스트뷰

            City weatherA = new City();
            weatherA.Number = "1)";
            weatherA.Name = "평균 기온";

            City weatherB = new City();
            weatherB.Number = "2)";
            weatherB.Name = "최저 기온";

            City weatherC = new City();
            weatherC.Number = "3)";
            weatherC.Name = "최고 기온";

            City weatherD = new City();
            weatherD.Number = "4)";
            weatherD.Name = "일강수량";

            City weatherE = new City();
            weatherE.Number = "5)";
            weatherE.Name = "최대 풍속";

            City weatherF = new City();
            weatherF.Number = "6)";
            weatherF.Name = "평균 풍속";

            City weatherG = new City();
            weatherG.Number = "7)";
            weatherG.Name = "평균 상대습도";

            City weatherH = new City();
            weatherH.Number = "8)";
            weatherH.Name = "평균 지면온도";

            Weathers.Add(weatherA);
            Weathers.Add(weatherB);
            Weathers.Add(weatherC);
            Weathers.Add(weatherD);
            Weathers.Add(weatherE);
            Weathers.Add(weatherF);
            Weathers.Add(weatherG);
            Weathers.Add(weatherH);

            ListView_Weather.ItemsSource = Weathers;

        }

        public class WeatherResponse
        {
            public Response response { get; set; }
        }

        public class Response
        {
            public Header Header { get; set; }
            public Body Body { get; set; }
        }

        public class Header
        {
            public string ResultCode { get; set; }
            public string ResultMsg { get; set; }
        }

        public class Body
        {
            public string DataType { get; set; }
            public Items Items { get; set; }
            public int PageNo { get; set; }
            public int NumOfRows { get; set; }
            public int TotalCount { get; set; }
        }

        public class Items
        {
            public List<Item> Item { get; set; }
        }

        public class Item
        {
            public string AvgTa { get; set; }           // 평균 기온
            public string MinTa { get; set; }           // 최저 기온
            public string MaxTa { get; set; }           // 최고 기온
            public string SumRn { get; set; }           // 일강수량
            public string MaxWs { get; set; }           // 최대 풍속
            public string AvgWs { get; set; }           // 평균 풍속
            public string AvgRhm { get; set; }          // 평균 상대습도
            public string AvgTs { get; set; }           // 평균 지면온도
        }
        static HttpClient client = new HttpClient();

        private void Enter_btn_Click(object sender, RoutedEventArgs e)
        {
            //string a = "&startDt=" + Start_Day.Text;
            //string b = "&endDt=" + End_Day.Text;
            //string c = "&stnIds=" + QnA_City.Text;
            string url = "http://apis.data.go.kr/1360000/AsosDalyInfoService/getWthrDataList"; // URL
            url += "?ServiceKey=" + "EcLzEiH0Mq4e9CZoDFCGmFN1Xb15WzdnW%2BPj%2BF0YZMvgo9f7soEVUV%2F%2BhRFNU5ao22S%2BlsZk3sGEV%2FaIGSqJuQ%3D%3D"; // Service Key
            url += "&pageNo=1";
            url += "&numOfRows=10";
            url += "&dataType=JSON";
            url += "&dataCd=ASOS";
            url += "&dateCd=DAY";                       // 기준
            url += "&startDt=" + Start_Day.Text;
            url += "&endDt=" + End_Day.Text;
            url += "&stnIds=" + QnA_City.Text;

            //MessageBox.Show(c, b);



            var request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "GET";

            string results = string.Empty;
            HttpWebResponse response;
            using (response = request.GetResponse() as HttpWebResponse)
            {
                StreamReader reader = new StreamReader(response.GetResponseStream());
                results = reader.ReadToEnd();
            }
            var weatherResponse = JsonConvert.DeserializeObject<WeatherResponse>(results);
            
            if (Weather.Text == "평균 기온")
            {
                Result.Text = null;
                foreach (var item in weatherResponse.response.Body.Items.Item)
                {
                    Result.Text += item.AvgTa + "\n";
                }
            }
            else if (Weather.Text == "최저 기온")
            {
                Result.Text = null;
                foreach (var item in weatherResponse.response.Body.Items.Item)
                {
                    Result.Text += item.MinTa + "\n";
                }
            }
            else if (Weather.Text == "최고 기온")
            {
                Result.Text = null;
                foreach (var item in weatherResponse.response.Body.Items.Item)
                {
                    Result.Text += item.MaxTa + "\n";
                }
            }
            else if (Weather.Text == "일강수량")
            {
                Result.Text = null;
                foreach (var item in weatherResponse.response.Body.Items.Item)
                {
                    Result.Text += item.SumRn + "\n";
                }
            }
            else if (Weather.Text == "최대 풍속")
            {
                Result.Text = null;
                foreach (var item in weatherResponse.response.Body.Items.Item)
                {
                    Result.Text += item.MaxWs + "\n";
                }
            }
            else if (Weather.Text == "평균 풍속")
            {
                Result.Text = null;
                foreach (var item in weatherResponse.response.Body.Items.Item)
                {
                    Result.Text += item.AvgWs + "\n";
                }
            }
            else if (Weather.Text == "평균 상대습도")
            {
                Result.Text = null;
                foreach (var item in weatherResponse.response.Body.Items.Item)
                {
                    Result.Text += item.AvgRhm + "\n";
                }
            }
            else if (Weather.Text == "평균 지면온도")
            {
                Result.Text = null;
                foreach (var item in weatherResponse.response.Body.Items.Item)
                {
                    Result.Text += item.AvgTs + "\n";
                }
            }
            else
            {
                Result.Text = "항목을 올바르게 입력해주세요.";
            }
            date_str = Weather.Text + " " + Result.Text + " " + Start_Day.Text + " " + End_Day.Text;
            Send(date_str);

        }
        static void JSON_INFO(String date_str, JObject JSON_STR)
        {
            JSON_STR["result"] = date_str;
            //JSON_STR["user_pw"] = user_info.User_pw;
        }
        private void Send(String date_str)
        {
            Change change = new Change(); // Change 클래스의 인스턴스를 생성합니다
            try
            {
                using (NetworkStream stream = client.GetStream())
                {
                    JObject JSON_STR = new JObject();
                    JSON_INFO(date_str, JSON_STR);
                    change.SERIALIZATION_to_send(JSON_STR, stream);
                    change.DESERIALIZATION_to_receive(JSON_STR, stream);
                }
            }
            catch (SocketException e)
            {
                MessageBox.Show("SocketException: " + e, "ERROR");
            }
            catch (Exception e)
            {
                MessageBox.Show("Exception: " + e, "ERROR");
            }
        }
    }
}
 

