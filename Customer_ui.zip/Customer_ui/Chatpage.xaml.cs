﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Customer_ui
{
    public partial class Chatpage : Page
    {
        private TcpClient client;
        static Total total = new Total();
        static JObject JSON_temp = new JObject();
        static ConcurrentQueue<string> receive_Queue = new ConcurrentQueue<string>();

        private bool isReceivingMessages;

        public Chatpage(TcpClient clientFromPreviousPage)
        {
            InitializeComponent();
            client = clientFromPreviousPage; // 전달된 TcpClient 객체를 저장합니다.

            isReceivingMessages = false;
        }

        private void back_btn_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Select(client));
        }

        static void Server_Address()            // take
        {
            total.Address.IP = "10.10.21.119";
            total.Address.Port = "1234";
        }
        static void Userinfo()                  // take
        {
            total.Information.user_name = "이준호";
            total.Information.user_id = "lee";
            total.Information.user_pw = "j";
        }
        void User_chat()                 // take
        {
            //total.User_chat.friend_id = Input_str("친구 아이디 입력 : ");
            total.User_chat.TEXT = Chat_Textbox.Text;
            //total.JSON_data["friend_id"] = total.User_chat.friend_id;
            total.JSON_data["text"] = total.User_chat.TEXT;
        }
        static void F_ID()                      // take
        {
            total.User_chat.friend_id = "kang";
            total.JSON_data["friend_id"] = total.User_chat.friend_id;
        }
        static void JSON_file()                 // plus
        {
            total.JSON_data["user_name"] = total.Information.user_name;
            total.JSON_data["user_id"] = total.Information.user_id;
            total.JSON_data["user_pw"] = total.Information.user_pw;
            total.JSON_data["text"] = total.User_chat.TEXT;

            total.JSON_data["friend_id"] = total.Information.friend_id;
        }
        static void JSON_combine(JObject JSON_temp, params (string Key, JToken Value)[] json_arr)           // take
        {
            foreach (var (Key, Value) in json_arr)
            {
                JSON_temp[Key] = Value;
            }
        }
        static async Task SERIALIZATION_to_send(JObject Sample_Json, NetworkStream stream)                  // check
        {
            var serialization_data = JsonConvert.SerializeObject(Sample_Json); // 직렬화
            byte[] data = Encoding.UTF8.GetBytes(serialization_data); // 직렬화 후 데이터 인코딩

            byte[] length = BitConverter.GetBytes(data.Length);//길이 측정

            if (BitConverter.IsLittleEndian)//통신 방법에 맞춤 빅엔디안으로 변경
                Array.Reverse(length);

            await stream.WriteAsync(length, 0, length.Length);
            await stream.WriteAsync(data, 0, data.Length);
        }
        async Task DESERIALIZATION_to_receive(NetworkStream stream)
        {
            byte[] data = new byte[256];
            int bytes = await stream.ReadAsync(data, 0, data.Length);
            string responseData = Encoding.UTF8.GetString(data, 0, bytes);
            var Deserialization_data = JsonConvert.DeserializeObject(responseData);// 역직렬화
            Application.Current.Dispatcher.Invoke(() =>
            {
                Example.Text += Deserialization_data;
            });
            JSON_temp = new JObject();
        }

        async Task AlwaysReceiveMessages(NetworkStream stream)
        {
            //try
            //{
            //    while (true)
            //    {
            //        await DESERIALIZATION_to_receive(stream);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine("Exception in receiving messages: {0}", ex);
            //}
            try
            {
                byte[] buffer = new byte[256];
                while (isReceivingMessages)
                {
                    int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                    //if (bytesRead == 0)
                    //{
                    //    // 서버가 연결을 닫은 경우 처리
                    //    isReceivingMessages = false;
                    //    break;
                    //}

                    string responseData = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                    var Deserialization_data = JsonConvert.DeserializeObject(responseData);

                    await Dispatcher.InvokeAsync(() =>
                    {
                        Example.Text =Deserialization_data + "\r\n";
                    });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in receiving messages: {0}", ex);
                // 예외 발생 시 적절히 처리
                isReceivingMessages = false;
            }
        }

        static string? Input_str(string str)            // take
        {
            Console.Write(str);
            return Console.ReadLine();
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            TcpClient client = null;
            try
            {
                Server_Address();
                client = new TcpClient(total.Address.IP, int.Parse(total.Address.Port));
                NetworkStream stream = client.GetStream();

                Userinfo();
                JSON_file();

                JSON_combine(JSON_temp,
                    ("user_name", total.JSON_data["user_name"]),
                    ("user_id", total.JSON_data["user_id"]));

                await SERIALIZATION_to_send(JSON_temp, stream);

                //Task receiveTask = Task.Run(() => AlwaysReceiveMessages(stream));
                //F_ID();

                //    User_chat();
                //    JSON_combine(JSON_temp, ("friend_id", total.JSON_data["friend_id"]), ("text", total.JSON_data["text"]));
                //    await SERIALIZATION_to_send(JSON_temp, stream);
                isReceivingMessages = true;
                await AlwaysReceiveMessages(stream);

            }
            catch (SocketException ex)
            {
                Console.WriteLine("SocketException: {0}", ex);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: {0}", ex);
            }
            Console.WriteLine("클라이언트를 종료");
        }

    }
    public class Total          // check
    {
        public Total()
        {
            Address = new Server_Address();
            Information = new USER_INFO();
            User_chat = new Chatting();
            JSON_data = new JObject();
        }

        public Server_Address Address { get; set; }
        public USER_INFO Information { get; set; }
        public Chatting User_chat { get; set; }
        public JObject JSON_data { get; set; }
    }

    public class USER_INFO
    {
        public string? user_name { get; set; }
        public string? friend_id { get; set; }
        public string? user_id { get; set; }
        public string? user_pw { get; set; }
    }

    public class Server_Address
    {
        public string? IP { get; set; }
        public string? Port { get; set; }
    }

    public class Chatting
    {
        public string? TEXT { get; set; }
        public string? friend_id { get; set; }
    }
}
