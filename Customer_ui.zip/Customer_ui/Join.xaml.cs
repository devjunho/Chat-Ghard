﻿using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Customer_ui.Models;

namespace Customer_ui
{
    public partial class Join : Page
    {
        private TcpClient client;

        public Join(TcpClient clientFromPreviousPage)
        {
            InitializeComponent();
            client = clientFromPreviousPage; // 전달된 TcpClient 객체를 저장합니다.
        }

        static void JSON_INFO(User user_info, JObject JSON_STR)
        {
            JSON_STR["join_id"] = user_info.User_id;
            JSON_STR["join_pw"] = user_info.User_pw;
            JSON_STR["join_name"] = user_info.User_name;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            User User_Info = new User();
            JObject JSON_STR = new JObject();

            if (string.IsNullOrEmpty(Name_box.Text) ||
                string.IsNullOrEmpty(ID_box.Text) ||
                string.IsNullOrEmpty(PW_box.Text) ||
                string.IsNullOrEmpty(PW_check.Text))
            {
                MessageBox.Show("빈칸 없이 입력해 주세요.", "ERROR");
            }
            else if (PW_box.Text == PW_check.Text)
            {
                User_Info.User_name = Name_box.Text;
                User_Info.User_id = ID_box.Text;
                User_Info.User_pw = PW_check.Text;
                MessageBox.Show("회원가입에 성공하였습니다.", "축하합니다.");

                // 전달받은 TcpClient 객체를 사용하여 서버와 통신합니다.
                Connect(User_Info);
                NavigationService.Navigate(new Uri("/Start.xaml", UriKind.Relative));
            }
            else if (PW_box.Text != PW_check.Text)
            {
                MessageBox.Show("비밀번호를 확인해주세요.", "ERROR");
            }
            else
            {
                MessageBox.Show("ERROR 발생", "ERROR");
            }
        }

        // 이 메소드에서 TcpClient 객체를 사용하여 서버와 통신합니다.
        private void Connect(User user_info)
        {
            Change change = new Change(); // Change 클래스의 인스턴스를 생성합니다
            try
            {
                using (NetworkStream stream = client.GetStream())
                {
                    JObject JSON_STR = new JObject();
                    JSON_INFO(user_info, JSON_STR);
                    change.SERIALIZATION_to_send(JSON_STR, stream);
                    change.DESERIALIZATION_to_receive(JSON_STR, stream);
                }
            }
            catch (SocketException e)
            {
                MessageBox.Show("SocketException: " + e, "ERROR");
            }
            catch (Exception e)
            {
                MessageBox.Show("Exception: " + e, "ERROR");
            }
        }
    }
}
