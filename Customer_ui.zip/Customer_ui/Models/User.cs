﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Customer_ui.Models
{
    class User
    {
        private string user_name;
        public string User_name
        {
            get { return user_name; }
            set { user_name = value; }
        }

        private string user_id;
        public string User_id
        {
            get { return user_id; }
            set { user_id = value; }
        }

        private string user_pw;
        public string User_pw
        {
            get { return user_pw; }
            set { user_pw = value; }
        }
    }
}
